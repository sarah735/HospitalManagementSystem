﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data.Entity;
using hms2.Models;
using System.Data;

namespace hms2.Manager
{
    public class patientmanager
    {
        SqlConnection con = new SqlConnection(@"Data Source=DELL-PC;Initial Catalog=HospitalManagementDB;Integrated Security=True");
        public bool addpatient(AddpatientModel ad)
        {
            string query = "insert into tblPatient(FirstName,LastName,Cellnum,CNIC,Disease,Gender,Nationality) values('"+ad.firstName+ "','" + ad.lastName + "','" + ad.cellnum + "','" + ad.cnic + "','" + ad.Disease + "','" + ad.gender + "','" + ad.nationality + "')";

            SqlCommand cmd = new SqlCommand(query, con);

            con.Open();
            int a = cmd.ExecuteNonQuery();
            con.Close();

            if (a > 0)
            {
                return true;

            }



            return false;
            //int adID;
            //using (hms2Entities hm = new hms2Entities())
            //{
            //    patient tblpatient = new patient();
            //    tblpatient.FirstName = ad.firstName;
            //    tblpatient.LastName = ad.lastName;
            //    tblpatient.Disease = ad.Disease;
            //    tblpatient.Cellnum = ad.cellnum;
            //    tblpatient.CNIC = ad.cnic;
            //    tblpatient.Gender = ad.gender;
            //    tblpatient.Nationality = ad.nationality;

            //    hm.patients.Add(tblpatient);

            //    hm.SaveChanges();

            //    adID = tblpatient.ID;

            //}
            //return adID;
        }

        public List<AddpatientModel> readstudents()
        {
            using (hms2Entities he = new hms2Entities())
            {
                var request = he.patients.ToList();
                List<AddpatientModel> List = request.Select(x => new AddpatientModel { pID = x.ID, firstName = x.FirstName, lastName = x.LastName, Disease = x.Disease, cellnum = x.Cellnum, cnic = x.CNIC, gender = x.Gender, nationality = x.Nationality }).ToList();
                return List;
            }
        }
        public AddpatientModel Getupdatepat(int pID)
        {
            Models.AddpatientModel sp = new Models.AddpatientModel();
            string query = "select * from tblPatient where ID='"+pID+"'";

            SqlCommand cmd = new SqlCommand(query, con);

            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
               

                sp.pID = Convert.ToInt32(reader[0].ToString());
                sp.firstName = reader[1].ToString();
                sp.lastName = reader[2].ToString();
                sp.cellnum = reader[4].ToString();
                sp.Disease = reader[3].ToString();
                sp.cnic = reader[5].ToString();
                sp.gender = reader[6].ToString();
                sp.nationality = reader[7].ToString();


              

            }
            con.Close();

            return sp;
            //using (hms2Entities hm = new Manager.hms2Entities())
            //{
            //    var request = hm.patients.Where(x => x.ID == pID).FirstOrDefault();
            //    AddpatientModel patnt = null;
            //    if (request != null)
            //    {
            //        patnt = new AddpatientModel()
            //        {
            //            pID = request.ID,
            //            firstName = request.FirstName,
            //            lastName = request.LastName,
            //            Disease = request.Disease,
            //            cellnum = request.Cellnum,
            //            cnic = request.CNIC,
            //            gender = request.Gender,
            //            nationality = request.Nationality

            //        };

            //        return patnt;
            //    }
            //    else
            //    {
            //        return patnt;
            //    }



        }
        

        public bool updatepat(AddpatientModel ad,int ID)
        {
            string query = "update tblPatient set FirstName='" + ad.firstName + "',LastName='" + ad.lastName + "',Cellnum='" + ad.cellnum + "',CNIC='" + ad.cnic + "',Disease='" + ad.Disease + "',Gender='" + ad.gender + "',Nationality='" + ad.nationality + "' where ID='"+ID+"'";

            SqlCommand cmd = new SqlCommand(query, con);

            con.Open();
            int a = cmd.ExecuteNonQuery();
            con.Close();

            if (a > 0)
            {
                return true;

            }



            return false;
        }
        public bool DeleteStd(int id)
        {
            string query = "Delete tblPatient where ID='" + id + "'";

            SqlCommand cmd = new SqlCommand(query, con);

            con.Open();
            int a = cmd.ExecuteNonQuery();
            con.Close();

            if (a > 0)
            {
                return true;

            }



            return false;
        }

        //static string conString = @"Data Source=DESKTOP-TKJ1DUH;Initial Catalog=hms2;Integrated Security=True";
        //     SqlConnection con = new SqlConnection(conString);
        //     public int addpatient(AddpatientModel patientt)
        //     {


        //         string query = "insert into	patient(FirstName,LastName,Disease,CNIC,Cellnum,Gender,Nationality) values('" + patientt.firstName + "','" + patientt.lastName + "','" + patientt.Disease +  "','" + patientt.cnic + "','" + patientt.cellnum + "','" + patientt.gender + "','" + patientt.nationality + "')";
        //         //string query = "INSERT INTO hms2.dbo.patient(FirstName) values('a')";
        //         con.Open();
        //         SqlCommand cmd = new SqlCommand(query, con);
        //         int a = cmd.ExecuteNonQuery();
        //         con.Close();

        //         return a;

        //     }

        public List<AddpatientModel> readStudents()
        {
            string query = "Select * from tblPatient";
            con.Open();
            SqlDataAdapter adp = new SqlDataAdapter(query, con);

            DataTable dt = new DataTable();
            adp.Fill(dt);
            con.Close();

            List<AddpatientModel> patientData = new List<AddpatientModel>();
            foreach (DataRow item in dt.Rows)
            {
                AddpatientModel cst = new AddpatientModel()
                {
                    pID= Convert.ToInt32(item["ID"].ToString()),
                    firstName = item["FirstName"].ToString(),
                    lastName = item["LastName"].ToString(),

                    Disease = item["Disease"].ToString(),
                    cellnum = item["Cellnum"].ToString(),
                    cnic = item["CNIC"].ToString(),
                    gender = item["Gender"].ToString(),
                    nationality = item["Nationality"].ToString()




                };

                patientData.Add(cst);

            }

            return patientData;
        }
    }
}




