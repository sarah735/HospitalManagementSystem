﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data.Entity;
using hms2.Models;
using System.Data;

namespace hms2.Manager
{
    public class doctormanager
    {
        SqlConnection con = new SqlConnection(@"Data Source=DELL-PC;Initial Catalog=HospitalManagementDB;Integrated Security=True");
        public bool adddoctor(Adddoctormodel ad)
        {

            string query = "insert into tblDoctor(FirstName,LastName,Cellnum,CNIC,qualification,Gender,Nationality) values('" + ad.firstName + "','" + ad.lastName + "','" + ad.cellnum + "','" + ad.cnic + "','" + ad.qualification + "','" + ad.gender + "','" + ad.nationality + "')";

            SqlCommand cmd = new SqlCommand(query, con);

            con.Open();
            int a = cmd.ExecuteNonQuery();
            con.Close();

            if (a > 0)
            {
                return true;

            }



            return false;
        }

        public List<Adddoctormodel> readstudents()
        {

            string query = "Select * from tblDoctor";
            con.Open();
            SqlDataAdapter adp = new SqlDataAdapter(query, con);

            DataTable dt = new DataTable();
            adp.Fill(dt);
            con.Close();

            List<Adddoctormodel> doctorData = new List<Adddoctormodel>();
            foreach (DataRow item in dt.Rows)
            {
                Adddoctormodel cst = new   Adddoctormodel()
                {
                    SID = Convert.ToInt32(item["ID"].ToString()),
                    firstName = item["FirstName"].ToString(),
                    lastName = item["LastName"].ToString(),

                    qualification = item["qualification"].ToString(),
                    cellnum = item["Cellnum"].ToString(),
                    cnic = item["CNIC"].ToString(),
                    gender = item["Gender"].ToString(),
                    nationality = item["Nationality"].ToString()




                };

                doctorData.Add(cst);

            }

            return doctorData;

        }

        public Adddoctormodel Getupdatedoc(int SID)
        {

            Models.Adddoctormodel sp = new Models.Adddoctormodel();
            string query = "select * from tblDoctor where ID='" + SID + "'";

            SqlCommand cmd = new SqlCommand(query, con);

            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {


                sp.SID = Convert.ToInt32(reader[0].ToString());
                sp.firstName = reader[1].ToString();
                sp.lastName = reader[2].ToString();
                sp.cellnum = reader[4].ToString();
                sp.qualification = reader[3].ToString();
                sp.cnic = reader[5].ToString();
                sp.gender = reader[6].ToString();
                sp.nationality = reader[7].ToString();




            }
            con.Close();

            return sp;
        }
        public bool updatedoc(Adddoctormodel ad,int ID)
        {
            string query = "update tblDoctor set FirstName='" + ad.firstName + "',LastName='" + ad.lastName + "',Cellnum='" + ad.cellnum + "',CNIC='" + ad.cnic + "',qualification='" + ad.qualification + "',Gender='" + ad.gender + "',Nationality='" + ad.nationality + "' where ID='" + ID + "'";

            SqlCommand cmd = new SqlCommand(query, con);

            con.Open();
            int a = cmd.ExecuteNonQuery();
            con.Close();

            if (a > 0)
            {
                return true;

            }



            return false;
        }
        public bool Deletedctr(int id)
        {
            string query = "Delete tblDoctor where ID='" + id + "'";

            SqlCommand cmd = new SqlCommand(query, con);

            con.Open();
            int a = cmd.ExecuteNonQuery();
            con.Close();

            if (a > 0)
            {
                return true;

            }



            return false;
        }

                //static string conString = @"Data Source=DESKTOP-TKJ1DUH;Initial Catalog=hms2;Integrated Security=True";
                //SqlConnection con = new SqlConnection(conString);

        //public int adddoctor(Adddoctormodel doctorr)
        //{
        //    string query = "insert into	doctor(FirstName,LastName,qualification,,CNIC,Cellnum,Gender,Nationality) values('" + doctorr.firstName + "','" + doctorr.lastName + "','" + doctorr.qualification + "','" + doctorr.cnic + "','" + doctorr.cellnum + "','" + doctorr.gender + "','" + doctorr.nationality + "')";
        //    con.Open();
        //    SqlCommand cmd = new SqlCommand(query, con);
        //    int a = cmd.ExecuteNonQuery();
        //    con.Close();

        //    return a;
        //}
        //public List<Adddoctormodel> readstudents()
        //{
        //    string query = "select * from doctor";
        //    con.Open();
        //    SqlDataAdapter adp = new SqlDataAdapter(query, con);

        //    DataTable ddt = new DataTable();
        //    adp.Fill(ddt);
        //    con.Close();


        //    List<Adddoctormodel> doctordata = new List<Adddoctormodel>();
        //    foreach (DataRow item in ddt.Rows)
        //    {
        //        Adddoctormodel adm = new Adddoctormodel()
        //        {
        //            firstName = item["FirstName"].ToString(),
        //            lastName = item["LastName"].ToString(),
        //            qualification = item["qualification"].ToString(),
        //            cellnum = item["Cellnum"].ToString(),
        //            cnic = item["CNIC"].ToString(),
        //            gender = item["Gender"].ToString(),
        //            nationality = item["Nationality"].ToString()




        //        };

        //        doctordata.Add(adm);

        //    }

        //    return doctordata;
    }
    }
            


        